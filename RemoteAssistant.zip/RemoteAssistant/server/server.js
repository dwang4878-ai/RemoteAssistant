'use strict';
const http = require('http');
const crypto = require('crypto');
const WebSocket = require('ws');
const PORT = Number(process.env.PORT || 8787);
const rooms = new Map();
const joinAttempts = new Map();
const MAX_ROOMS = 500;
const JOIN_WINDOW_MS = 60_000;
const MAX_JOIN_ATTEMPTS = 8;
const APPROVAL_TIMEOUT_MS = 45_000;
const COMMAND_WINDOW_MS = 1_000;
const MAX_COMMANDS_PER_WINDOW = 30;
const code = () => String(crypto.randomInt(100000, 1000000));
const server = http.createServer((req, res) => {
  if (req.url === '/health') {
    res.writeHead(200, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' });
    return res.end(JSON.stringify({ ok: true, activeRooms: rooms.size }));
  }
  res.writeHead(200, { 'content-type': 'text/plain; charset=utf-8', 'cache-control': 'no-store' });
  res.end('RemoteAssistant relay is running. WebSocket endpoint: /ws; health: /health');
});
const wss = new WebSocket.Server({ server, path: '/ws', maxPayload: 2 * 1024 * 1024, perMessageDeflate: false });
function send(ws, obj) { if (ws && ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(obj)); }
function remove(ws) {
  const room = ws.room && rooms.get(ws.room);
  if (!room) return;
  if (room.host === ws) { send(room.controller, { type: 'host_disconnected' }); rooms.delete(ws.room); }
  else if (room.controller === ws) { send(room.host, { type: 'controller_disconnected' }); room.controller = null; room.approved = false; room.approvalDeadline = null; }
}
// Expire abandoned pairing rooms even if a peer remains connected.
setInterval(() => {
  for (const [id, room] of rooms) {
    if (room.expires < Date.now()) {
      send(room.host, { type: 'expired' }); send(room.controller, { type: 'expired' });
      try { room.host.close(1000, 'pairing expired'); } catch {}
      try { room.controller?.close(1000, 'pairing expired'); } catch {}
      rooms.delete(id);
      continue;
    }
    if (room.controller && !room.approved && room.approvalDeadline && room.approvalDeadline < Date.now()) {
      send(room.controller, { type: 'approval_timeout' });
      send(room.host, { type: 'controller_timeout' });
      try { room.controller.close(1000, 'approval timed out'); } catch {}
      room.controller = null;
      room.approvalDeadline = null;
    }
  }
}, 30_000).unref();

wss.on('connection', ws => {
  ws.on('message', (raw, isBinary) => {
    if (raw.length > 2 * 1024 * 1024) { ws.close(1009, 'message too large'); return; }
    if (isBinary) {
      const room = rooms.get(ws.room);
      if (room && room.approved && room.host === ws && room.controller) {
        if (raw.length <= 2 * 1024 * 1024) room.controller.send(raw, { binary: true });
      }
      return;
    }
    let m; try { m = JSON.parse(raw.toString()); } catch { return send(ws, { type: 'error', message: 'Invalid JSON' }); }
    if (m.type === 'create') {
      if (ws.role === 'controller') return send(ws, { type: 'error', message: '控制端不能创建被控房间' });
      if (rooms.size >= MAX_ROOMS) return send(ws, { type: 'error', message: '服务器繁忙，请稍后重试' });
      if (ws.room) remove(ws);
      let id; do { id = code(); } while (rooms.has(id));
      rooms.set(id, { host: ws, controller: null, approved: false, expires: Date.now() + 10 * 60 * 1000 });
      ws.room = id; ws.role = 'host'; send(ws, { type: 'created', code: id, expiresIn: 600 });
    } else if (m.type === 'join') {
      const ip = String(ws._socket?.remoteAddress || 'unknown');
      const now = Date.now();
      const attempts = (joinAttempts.get(ip) || []).filter(t => now - t < JOIN_WINDOW_MS);
      if (attempts.length >= MAX_JOIN_ATTEMPTS) return send(ws, { type: 'error', message: '尝试次数过多，请一分钟后再试' });
      attempts.push(now); joinAttempts.set(ip, attempts);
      const id = String(m.code || '').replace(/\D/g, '').slice(0, 6), room = rooms.get(id);
      if (!/^\d{6}$/.test(String(m.code || ''))) return send(ws, { type: 'error', message: '请输入 6 位数字连接码' });
      if (!room || room.expires < Date.now() || room.controller) return send(ws, { type: 'error', message: '连接码无效、过期或已被使用' });
      room.controller = ws; room.approved = false; room.approvalDeadline = Date.now() + APPROVAL_TIMEOUT_MS;
      room.commandWindowStart = 0; room.commandCount = 0;
      ws.room = id; ws.role = 'controller';
      send(ws, { type: 'waiting_host' }); send(room.host, { type: 'controller_waiting' });
    } else if (m.type === 'approve' || m.type === 'reject') {
      const room = rooms.get(ws.room);
      if (!room || room.host !== ws || !room.controller) return;
      room.approved = m.type === 'approve';
      room.approvalDeadline = null;
      // Notify both peers: the host must also enable frame streaming and local command handling.
      const controller = room.controller;
      send(controller, { type: room.approved ? 'approved' : 'rejected' });
      send(room.host, { type: room.approved ? 'host_approved' : 'host_rejected' });
      // A rejected controller must not reserve the room or keep a stale session alive.
      if (!room.approved && controller) {
        room.controller = null;
        controller.room = null;
        try { controller.close(1000, 'rejected by host'); } catch {}
      }
    } else if (m.type === 'command') {
      const room = rooms.get(ws.room);
      if (!room || !room.approved || room.controller !== ws) return send(ws, { type: 'error', message: '尚未获得手机端授权' });
      // 控制指令限速，避免误触或恶意脚本造成高频操作。
      const now = Date.now();
      if (now - (room.commandWindowStart || 0) >= COMMAND_WINDOW_MS) { room.commandWindowStart = now; room.commandCount = 0; }
      room.commandCount = (room.commandCount || 0) + 1;
      if (room.commandCount > MAX_COMMANDS_PER_WINDOW) return send(ws, { type: 'error', message: '操作过快，请稍后再试' });
      const allowed = ['tap', 'swipe', 'back', 'home'];
      if (!m.action || !allowed.includes(m.action)) return;
      const norm = v => { const n = Number(v); return Number.isFinite(n) ? Math.max(0, Math.min(1, n)) : 0; };
      send(room.host, { type: 'command', action: m.action, x: norm(m.x), y: norm(m.y), x2: norm(m.x2), y2: norm(m.y2), duration: Math.min(1500, Math.max(100, Number(m.duration) || 350)) });
    } else if (m.type === 'close') { remove(ws); ws.room = null; send(ws, { type: 'closed' }); }
  });
  ws.on('close', () => remove(ws));
});
setInterval(() => {
  const now = Date.now();
  for (const [ip, attempts] of joinAttempts) {
    const fresh = attempts.filter(t => now - t < JOIN_WINDOW_MS);
    if (fresh.length) joinAttempts.set(ip, fresh); else joinAttempts.delete(ip);
  }
}, JOIN_WINDOW_MS).unref();
server.listen(PORT, '0.0.0.0', () => console.log(`RemoteAssistant relay listening on ${PORT}`));

// Export handles for deterministic automated tests; normal `node server.js` behavior is unchanged.
module.exports = { server, wss, rooms };
