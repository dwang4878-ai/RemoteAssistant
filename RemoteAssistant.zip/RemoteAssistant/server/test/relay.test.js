// Dependency-free relay protocol tests using a tiny WebSocket test double.
// These validate server routing/state logic, not real network/TLS behavior.
const test = require('node:test');
const assert = require('node:assert/strict');
const EventEmitter = require('node:events');
const Module = require('node:module');

class FakeSocket extends EventEmitter {
  constructor(ip = '127.0.0.1') {
    super(); this.readyState = 1; this._socket = { remoteAddress: ip };
    this.sent = []; this.room = null; this.role = null;
  }
  send(data) { this.sent.push(data); }
  close() { if (this.readyState === 3) return; this.readyState = 3; this.emit('close'); }
  messages() { return this.sent.filter(x => typeof x === 'string').map(x => JSON.parse(x)); }
  last(type) { return this.messages().filter(x => x.type === type).at(-1); }
  receive(obj) { this.emit('message', Buffer.from(JSON.stringify(obj)), false); }
}
class FakeWebSocketServer extends EventEmitter {
  constructor(options) { super(); this.options = options; }
}
const fakeWs = { OPEN: 1, Server: FakeWebSocketServer };
const originalLoad = Module._load;
Module._load = function(request, parent, isMain) {
  if (request === 'ws') return fakeWs;
  return originalLoad.call(this, request, parent, isMain);
};
process.env.PORT = '0';
const app = require('../server.js');
Module._load = originalLoad;
const { server, wss, rooms } = app;
const connect = (ip) => { const s = new FakeSocket(ip); wss.emit('connection', s); return s; };
const waitListening = () => new Promise(resolve => server.listening ? resolve() : server.once('listening', resolve));
let port;
test.before(async () => { await waitListening(); port = server.address().port; });
test.after(() => new Promise(resolve => server.close(resolve)));

test('health endpoint reports relay availability', async () => {
  const response = await fetch(`http://127.0.0.1:${port}/health`);
  assert.equal(response.status, 200);
  assert.equal((await response.json()).ok, true);
});

test('pairing requires explicit approval; commands and frames route only in allowed directions', () => {
  const host = connect('10.0.0.1');
  host.receive({ type: 'create' });
  const code = host.last('created').code;
  assert.match(code, /^\d{6}$/);
  assert.equal(rooms.size, 1);

  const controller = connect('10.0.0.2');
  controller.receive({ type: 'join', code });
  assert.equal(controller.last('waiting_host').type, 'waiting_host');
  assert.equal(host.last('controller_waiting').type, 'controller_waiting');
  controller.receive({ type: 'command', action: 'tap', x: 0.5, y: 0.5 });
  assert.equal(host.last('command'), undefined);

  host.receive({ type: 'approve' });
  assert.equal(host.last('host_approved').type, 'host_approved');
  assert.equal(controller.last('approved').type, 'approved');
  controller.receive({ type: 'command', action: 'tap', x: 0.5, y: 0.4 });
  assert.deepEqual(host.last('command'), { type: 'command', action: 'tap', x: 0.5, y: 0.4, x2: 0, y2: 0, duration: 350 });

  const frame = Buffer.from([0xff, 0xd8, 0xff, 0xd9]);
  const before = controller.sent.filter(x => Buffer.isBuffer(x)).length;
  host.emit('message', frame, true);
  assert.equal(controller.sent.filter(x => Buffer.isBuffer(x)).length, before + 1);
  const hostBefore = host.sent.filter(x => Buffer.isBuffer(x)).length;
  controller.emit('message', frame, true);
  assert.equal(host.sent.filter(x => Buffer.isBuffer(x)).length, hostBefore);

  controller.receive({ type: 'close' });
  assert.equal(host.last('controller_disconnected').type, 'controller_disconnected');
  assert.equal(rooms.get(code).approved, false);
  host.receive({ type: 'close' });
  assert.equal(rooms.size, 0);
});

test('rejecting a controller releases the room for a fresh pairing', () => {
  const host = connect('10.0.1.1');
  host.receive({ type: 'create' });
  const code = host.last('created').code;
  const first = connect('10.0.1.2');
  first.receive({ type: 'join', code });
  host.receive({ type: 'reject' });
  assert.equal(first.last('rejected').type, 'rejected');
  assert.equal(first.readyState, 3);
  assert.equal(rooms.get(code).controller, null);
  assert.equal(rooms.get(code).approved, false);

  const second = connect('10.0.1.3');
  second.receive({ type: 'join', code });
  assert.equal(second.last('waiting_host').type, 'waiting_host');
  host.receive({ type: 'close' });
});

test('malformed connection codes are rejected without creating a room', () => {
  const controller = connect('10.0.2.2');
  controller.receive({ type: 'join', code: '12ab' });
  assert.match(controller.last('error').message, /6 位数字/);
  assert.equal(rooms.size, 0);
});

test('join attempts are rate limited per source address', () => {
  const ip = '10.0.3.9';
  for (let i = 0; i < 8; i++) {
    const controller = connect(ip);
    controller.receive({ type: 'join', code: '000000' });
  }
  const ninth = connect(ip);
  ninth.receive({ type: 'join', code: '000000' });
  assert.match(ninth.last('error').message, /尝试次数过多/);
});
