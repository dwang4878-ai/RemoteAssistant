plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.remoteassistant.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.remoteassistant.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "0.2.0"
    }
}


dependencies {
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
}
