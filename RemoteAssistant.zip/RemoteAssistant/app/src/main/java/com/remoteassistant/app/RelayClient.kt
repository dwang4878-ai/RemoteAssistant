package com.remoteassistant.app

import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class RelayClient(private val listener: (JSONObject) -> Unit) {
    private val client = OkHttpClient.Builder().pingInterval(25, TimeUnit.SECONDS).build()
    private var socket: WebSocket? = null
    @Volatile private var approved = false
    fun isApproved(): Boolean = approved

    fun connect(url: String, onConnected: () -> Unit = {}) {
        disconnect()
        val cleanUrl = url.trim()
        require(cleanUrl.startsWith("wss://", ignoreCase = true)) { "为保护连接码、屏幕画面和操作指令，请使用 wss:// 加密地址" }
        val request = Request.Builder().url(cleanUrl).build()
        socket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: okhttp3.Response) {
                // Ignore callbacks from an older socket after the user reconnects.
                if (socket === webSocket) onConnected()
            }
            override fun onMessage(webSocket: WebSocket, text: String) {
                runCatching { JSONObject(text) }.getOrNull()?.let { message ->
                    when (message.optString("type")) {
                        "approved", "host_approved" -> approved = true
                        "rejected", "host_rejected", "closed", "expired", "approval_timeout", "host_disconnected", "controller_disconnected" -> approved = false
                    }
                    listener(message)
                }
            }
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                if (socket === webSocket) {
                    approved = false
                    socket = null
                    listener(JSONObject().put("type", "transport_disconnected").put("message", reason))
                }
            }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: okhttp3.Response?) {
                if (socket === webSocket) {
                    approved = false
                    socket = null
                    listener(JSONObject().put("type", "transport_disconnected").put("message", t.message ?: "网络连接失败"))
                }
            }
        })
    }

    fun send(type: String, extra: JSONObject = JSONObject()) {
        extra.put("type", type)
        socket?.send(extra.toString())
    }
    fun sendBinary(bytes: ByteArray): Boolean = socket?.send(ByteString.of(*bytes)) ?: false
    fun disconnect() { approved = false; socket?.close(1000, "user closed"); socket = null }
}
