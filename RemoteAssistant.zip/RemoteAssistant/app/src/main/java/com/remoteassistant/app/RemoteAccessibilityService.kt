package com.remoteassistant.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Build
import android.view.accessibility.AccessibilityEvent
import org.json.JSONObject

object RemoteAssistantSession { @Volatile var relay: RelayClient? = null }

class RemoteAccessibilityService : AccessibilityService() {
    companion object { @Volatile var instance: RemoteAccessibilityService? = null }
    override fun onServiceConnected() { super.onServiceConnected(); instance = this }
    override fun onDestroy() { if (instance === this) instance = null; super.onDestroy() }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() = Unit

    fun performRemoteCommand(command: JSONObject) {
        // Double-check approval locally; no remote gesture is run before the relay confirms consent.
        if (RemoteAssistantSession.relay?.isApproved() != true) return
        val metrics = resources.displayMetrics
        val x = (command.optDouble("x", 0.0) * metrics.widthPixels).toFloat().coerceIn(0f, metrics.widthPixels.toFloat())
        val y = (command.optDouble("y", 0.0) * metrics.heightPixels).toFloat().coerceIn(0f, metrics.heightPixels.toFloat())
        val path = Path().apply { moveTo(x, y) }
        when (command.optString("action")) {
            "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
            "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
            "tap" -> dispatch(path, 80)
            "swipe" -> {
                val x2 = (command.optDouble("x2", 0.0) * metrics.widthPixels).toFloat().coerceIn(0f, metrics.widthPixels.toFloat())
                val y2 = (command.optDouble("y2", 0.0) * metrics.heightPixels).toFloat().coerceIn(0f, metrics.heightPixels.toFloat())
                path.lineTo(x2, y2); dispatch(path, command.optLong("duration", 350).coerceIn(100, 1500))
            }
        }
    }
    private fun dispatch(path: Path, duration: Long) {
        val gesture = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, duration)).build()
        dispatchGesture(gesture, null, null)
    }
}
