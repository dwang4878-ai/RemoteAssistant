package com.remoteassistant.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject

class MainActivity : Activity() {
    private val projectionRequest = 4101
    private lateinit var status: TextView
    private lateinit var codeView: TextView
    private lateinit var relay: RelayClient
    private var pendingController = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        relay = RelayClient { message -> runOnUiThread { handleRelayMessage(message) } }
        RemoteAssistantSession.relay = relay
        val pad = (20 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad * 2, pad, pad); gravity = Gravity.TOP }
        layout.addView(TextView(this).apply { text = "远程助手"; textSize = 28f })
        layout.addView(TextView(this).apply { text = "被控设备：一加 13\n请只与可信任的人分享连接码。每次连接都需要你确认。"; textSize = 16f; setPadding(0, pad, 0, pad) })
        val server = EditText(this).apply { hint = "中继服务器地址，例如 wss://你的服务器/ws"; setSingleLine(true); setText("wss://") }
        layout.addView(server, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        layout.addView(Button(this).apply { text = "连接中继并生成连接码"; setOnClickListener { status.text = "正在连接中继…"; runCatching { relay.connect(server.text.toString()) { relay.send("create") } }.onFailure { status.text = "地址有误：${it.message}" } } }, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        codeView = TextView(this).apply { text = "连接码：尚未生成"; textSize = 22f; setPadding(0, pad, 0, pad) }; layout.addView(codeView)
        status = TextView(this).apply { text = "状态：未连接"; textSize = 15f }; layout.addView(status)
        layout.addView(Button(this).apply { text = "断开远程连接"; setOnClickListener { relay.send("close"); relay.disconnect(); status.text = "状态：已断开"; codeView.text = "连接码：尚未生成" } }, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        layout.addView(Button(this).apply { text = "① 开启屏幕共享授权"; setOnClickListener { val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager; startActivityForResult(manager.createScreenCaptureIntent(), projectionRequest) } }, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        layout.addView(Button(this).apply { text = "停止屏幕共享"; setOnClickListener {
            stopService(Intent(this@MainActivity, ScreenCaptureService::class.java))
            status.text = "状态：屏幕共享已停止"
        } }, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        layout.addView(Button(this).apply { text = "② 设置远程操作权限"; setOnClickListener { startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS)) } }, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        layout.addView(TextView(this).apply { text = "安全提示：请使用可信任的 wss:// 中继地址。不要在公网使用未加密的 ws:// 服务。屏幕共享需单独授权；远程操作需手动开启无障碍权限。"; textSize = 13f; setPadding(0, pad, 0, 0) })
        setContentView(layout)
    }

    private fun handleRelayMessage(m: JSONObject) {
        when (m.optString("type")) {
            "created" -> { codeView.text = "连接码：${m.optString("code")}"; status.text = "状态：等待控制端连接（10 分钟有效）" }
            "controller_waiting" -> {
                pendingController = true
                AlertDialog.Builder(this).setTitle("远程连接请求").setMessage("有人输入了你的连接码。确认是你认识的人后再允许操作。")
                    .setPositiveButton("允许本次连接") { _, _ -> relay.send("approve"); status.text = "状态：已授权控制端" }
                    .setNegativeButton("拒绝") { _, _ -> relay.send("reject"); status.text = "状态：已拒绝连接" }
                    .setOnCancelListener { relay.send("reject") }.show()
            }
            "host_approved" -> { status.text = "状态：本次远程连接已批准；屏幕帧可在共享授权有效时发送" }
            "approval_timeout" -> {
                status.text = "状态：等待手机确认超时，请重新连接"
            }
            "controller_timeout" -> {
                status.text = "状态：控制端未在规定时间内获得批准，可重新连接"
            }
            "host_rejected" -> {
                status.text = "状态：已拒绝本次连接"
                stopService(Intent(this, ScreenCaptureService::class.java))
            }
            "expired" -> {
                status.text = "状态：连接码已过期，请重新生成"
                codeView.text = "连接码：已过期"
                stopService(Intent(this, ScreenCaptureService::class.java))
            }
            "command" -> RemoteAccessibilityService.instance?.performRemoteCommand(m)
            "controller_disconnected" -> {
                status.text = "状态：控制端已断开，屏幕共享已暂停"
                stopService(Intent(this, ScreenCaptureService::class.java))
            }
            "host_disconnected" -> {
                status.text = "状态：手机端连接已断开"
                codeView.text = "连接码：尚未生成"
                stopService(Intent(this, ScreenCaptureService::class.java))
            }
            "transport_disconnected" -> {
                // A transport failure revokes the local session too; never leave capture running
                // merely because the WebSocket disappeared without a protocol-level close event.
                status.text = "状态：中继网络已断开，远程会话已停止"
                codeView.text = "连接码：尚未生成"
                stopService(Intent(this, ScreenCaptureService::class.java))
                pendingController = false
            }
            "error" -> status.text = "状态：${m.optString("message")}"
            "closed" -> status.text = "状态：已断开"
        }
    }

    @Deprecated("Deprecated by Android; retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == projectionRequest && resultCode == RESULT_OK && data != null) {
            val service = Intent(this, ScreenCaptureService::class.java).apply { putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode); putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data) }
            startForegroundService(service)
            Toast.makeText(this, "已取得本次屏幕共享授权", Toast.LENGTH_LONG).show()
        }
    }
    override fun onDestroy() { relay.disconnect(); RemoteAssistantSession.relay = null; super.onDestroy() }
}
