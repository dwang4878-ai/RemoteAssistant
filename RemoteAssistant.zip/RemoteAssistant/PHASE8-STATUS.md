# 第八阶段状态

## 本轮修改
Android RelayClient 现在强制要求 `wss://`，不再允许 `ws://`。连接码、屏幕帧和远程操作指令均属于敏感数据，明文 WebSocket 不应被用于真实会话。README 补充了 TLS 反向代理部署要求。

## 验证
- `node --test server/test/*.test.js`：5 项通过。
- ZIP 完整性检查：通过。
- Android Kotlin 编译：未验证，当前环境无 Gradle/Android SDK。
- APK：未生成。
- TLS 真实部署与证书验证：未完成。
- 一加 13 真机：未测试。
