# 第七阶段状态

## 本轮修改
MainActivity 新增处理 `transport_disconnected`：清除连接码与等待状态，并停止屏幕采集服务。之前 RelayClient 已在 WebSocket onClosed/onFailure 时发出该事件并将 approved 置为 false，但 Activity 未处理，导致前台采集服务可能继续运行（虽然不会继续发帧）。

## 验证
- `node --test server/test/*.test.js`：5/5 通过。
- Gradle/Android SDK：当前运行环境未安装；访问 services.gradle.org 与 dl.google.com 的 DNS 解析失败，无法在本环境下载构建工具。
- Kotlin/Android 构建：未验证。
- APK：未生成。
- 一加 13 真机：未测试。
