# 第四阶段：Android 屏幕采集与无障碍手势接入（源码原型）

本阶段把 Android 端的 MediaProjection 图像采集接入中继二进制帧发送，并加入 AccessibilityService 对 tap / swipe / back / home 的执行入口。远程命令在 Android 端再次检查本地连接授权状态；屏幕帧只有中继收到 host 已批准的会话后才发送。

## 尚未完成/验证
- 本工作环境没有 Android SDK、Gradle 或 Android Studio，因此无法在此编译 APK，也无法在一加 13 / Android 17 真机验证 Kotlin/系统权限行为。
- 目前 WebSocket 中继是开发原型：没有身份认证、端到端加密、TURN/WebRTC、抗重放机制或生产级限流。不可直接暴露到公网处理隐私屏幕内容。
- 浏览器控制台的坐标仍基于演示区域比例，尚未与真实屏幕方向、状态栏/导航栏及显示尺寸精确同步。
- Android 14+ 的 MediaProjection 会话规则、Android 17 的具体行为需要在目标系统真机测试；用户必须每次明确授予屏幕捕获权限并开启无障碍服务。
- 连接中继服务器的地址必须由部署者提供；默认模拟器地址不是公网服务地址。

## 真正交付标准
成功构建 APK；安装到一加 13；验证授权弹窗、屏幕帧、点击/滑动、断开即停止、重新授权；完成安全传输和部署文档。当前仍是开发源码，不是已验证可用的远程控制成品。

## 第五阶段补充：连接时序修正
- 修复 Android 客户端在 WebSocket 尚未完成握手时就发送 create 的竞态：现在收到 onOpen 后才创建配对码。
- 中继地址增加 ws/wss 前缀校验，界面默认提示填写 TLS 的 wss 地址。
- 这只是源码级修正；当前环境未安装 Android SDK/Gradle，且未安装 Node 依赖，因此尚未进行 APK 构建或真实中继联调。
